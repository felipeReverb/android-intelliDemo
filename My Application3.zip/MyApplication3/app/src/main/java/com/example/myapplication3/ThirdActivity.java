package com.example.myapplication3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.ActivityChooserView;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class ThirdActivity extends AppCompatActivity {

    private EditText editTxtMonto;
    private EditText editTxtReference;
    private Button btnPay;
    private TextView txtDisplay;
    private EditText txtEditName; // input para nombre de producto




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);


        editTxtMonto = (EditText) findViewById(R.id.editTextMonto);
        editTxtReference = (EditText) findViewById(R.id.editTextReference);
        btnPay = (Button) findViewById(R.id.imageButtonPay);
        txtDisplay = (TextView) findViewById(R.id.resultView);


        /*Boton para la llamada

        imgBtnPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = editTextPhone.getText().toString();
                if(phoneNumber != null){
                    //Comprobar version actual de Android que esta corriendo
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){

                        //Comprobar si ha aceptado , no ha aceptado o nunca se le ha preguntado
                        if(CheckPermission(Manifest.permission.CALL_PHONE)){
                            // Ha aceptado los permisos
                            Intent i = new Intent(Intent.ACTION_CALL,Uri.parse("tel:"+phoneNumber));
                            if (ActivityCompat.checkSelfPermission(ThirdActivity.this, Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED) return;
                            startActivity(i);
                        }else{
                            //Ha denedado o es la primera vez que se le pregunta
                            if(!shouldShowRequestPermissionRationale(Manifest.permission.CALL_PHONE)){
                                //No se le ha preguntado aun
                                requestPermissions(new String[]{Manifest.permission.CALL_PHONE},PHONE_CALL_CODE);
                            } else {
                                //HA denegado
                                Toast.makeText(ThirdActivity.this,"Please enable the permission", Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                i.addCategory(Intent.CATEGORY_DEFAULT);
                                i.setData(Uri.parse("package:"+ getPackageName()));
                                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                                i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                                startActivity(i);
                            }
                        }

                    }else {
                        OlderVersions(phoneNumber);
                    }
                }
            }

            private void OlderVersions(String phoneNumber){
                Intent intentCall = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+ phoneNumber));
                if (CheckPermission(Manifest.permission.CALL_PHONE)){
                    startActivity(intentCall);
                }else {
                    Toast.makeText(ThirdActivity.this, "You decline the access", Toast.LENGTH_SHORT).show();
                }
            }
        });


         */

        /*Boton para la direccion web

        imgBtnWeb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = editTextWeb.getText().toString();
                if(url != null && !url.isEmpty()){
                    Intent intentWeb = new Intent(Intent.ACTION_VIEW, Uri.parse("https://qa5.mitec.com.mx/p/i/Y2DO6O0"+url));
                    startActivity(intentWeb);
                }
            }
        });
        */

        //Boton para invocar el pago
        btnPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String monto = editTxtMonto.getText().toString();
                String reference = editTxtReference.getText().toString();
                String uri = "https://execute-payment/pay?TrxAmount="+monto+"&TrxCurrency=1&TrxUser=1234&TrxReference="+reference+"&License=5FW3fT5v-R7G3&TrxType=1&PType=1";
                Intent intentPay = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                startActivityForResult(intentPay, 666);
            }
        });

    }

    //Recuperar el resultado del intentPay,

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 666) { //Este es el número de Bundle que usaste en el Intent
            String TrxResult = data.getStringExtra("TrxResult");
            String TrxAmount = data.getStringExtra("TrxAmount");
            String TrxCard = data.getStringExtra("TrxCard");
            String TrxAuthNumber = data.getStringExtra("TrxAuthNumber");
            String TrxOrgNumber = data.getStringExtra("TrxOrgNumber");
            String TrxCardType = data.getStringExtra("TrxCardType");
            String TrxMerchant = data.getStringExtra("TrxMerchant");
            String TrxARQC = data.getStringExtra("TrxARQC");
            String TrxAID = data.getStringExtra("TrxAID");
            String TrxBank = data.getStringExtra("TrxBank");
            String TrxCardInstrument = data.getStringExtra("TrxCardInstrument");
            String TrxPaymentMode = data.getStringExtra("TrxPaymentMode");
            String TrxReference = data.getStringExtra("TrxReference");
            String TrxRoomNbr = data.getStringExtra("TrxRoomNbr");

            txtDisplay.setText("Pago: "+TrxResult+"\n"+"Monto: "+TrxAmount+"\n"+"Autorizacion: "+TrxAuthNumber);
            editTxtMonto.setText("");
            editTxtReference.setText("");
        }
    }

    /*
//Validacion de permisos de acuerdo ala version de android
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //Estamos en el caso del telefono
        switch (requestCode){
            case PHONE_CALL_CODE:
                String permission = permissions[0];
                int result = grantResults[0];

                if(permission.equals(Manifest.permission.CALL_PHONE)){

                    //Comprobar si ha sido aceptado o denegado la peticion del permiso
                    if (result == PackageManager.PERMISSION_GRANTED){
                        //Si es True pues concedio su permiso men
                        String phoneNumber = editTxtMonto.getText().toString();
                        Intent intentCall = new Intent(Intent.ACTION_CALL,Uri.parse("tel:" + phoneNumber));
                        startActivity(intentCall);
                    }else{
                        //No concedio el permiso el usuario
                        Toast.makeText(ThirdActivity.this, "You decline the access man",Toast.LENGTH_SHORT).show();
                    }
                }
                break;

        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
*/
    private boolean CheckPermission(String permission){
        int result = this.checkCallingOrSelfPermission(permission);
        return result == PackageManager.PERMISSION_GRANTED;
    }

}
